// Subjects Data
const subjectsData = {
    "Class 5": ["Math", "Science"],
    "Class 6": ["Math", "Science", "English"],
    "Class 7": ["Math", "Physics", "Chemistry"],
    "Class 8": ["Algebra", "Physics", "Chemistry"],
    "Class 9": ["Math", "Physics", "Biology"],
    "Class 10": ["Trigonometry", "Physics", "Biology"],
    "Intermediate 1st Year": ["Physics", "Chemistry", "Biology", "Math"],
    "Intermediate 2nd Year": ["Physics", "Chemistry", "Biology", "Math"],
    "CSE": ["Data Structures", "C", "C++", "Java", "Python", "Operating Systems", "AI & ML"],
    "ECE": ["Digital Circuits", "BEEE", "ADC", "Embedded Systems", "VLSI"],
    "EEE": ["Power Systems", "Control Systems", "Electrical Machines"],
    "Mechanical": ["Thermodynamics", "Fluid Mechanics", "Manufacturing"],
    "Civil": ["Structural Analysis", "Concrete Technology", "Surveying"]
};

// Experiments Data
const experimentsData = {
    "Class 5": {
        "Math": [
            { name: "Fractions Experiment", url: "fractions.html" },
            { name: "Geometry Exploration", url: "geometry.html" }
        ],
        "Science": [
            { name: "Water Cycle Model", url: "water-cycle.html" },
            { name: "Plant Life Observation", url: "plant-life.html" }
        ],
        
        
    },
    "Class 6": {
        "Math": [
            { name: "Algebra Basics", url: "algebra-basics.html" },
            { name: "Linear Equations", url: "linear-equations.html" }
        ],
        "Science": [
            { name: "Electricity Demo", url: "electricity-demo.html" },
            { name: "Earthquake Simulation", url: "earthquake-simulation.html" }
        ],
        "English": [
            { name: "Grammar Analysis", url: "grammer-analysis.html" },
            { name: "Essay Structure", url: "essay-structure.html" }
        ]
    },
    "Class 7": {
        "Math": [
            { name: "Percentages", url: "percentages.html" },
            { name: "Integers", url: "integers.html" }
            ],
            "Physics": [
                { name: "Light Reflection", url: "light-reflection.html" },
                
            ],
            "Chemistry": [
                { name: "Chemical Changes", url: "chemical-changes.html" },
                { name: "Matter State Experiment", url: "matter-state-experiment.html" }
            ]
        },
        "Class 8": {
            "Algebra": [
                { name: "Quadratic Equations", url: "quadratic-equations.html" },
                { name: "Polynomials", url: "polynomials.html" }
            ],
            "Physics": [
                { name: "Sound Waves", url: "sound-waves.html" },
                { name: "Mechanical Waves", url: "mechanical-waves.html" }
            ],
            "Chemistry": [
                { name: "Acids and Bases", url: "acids-and-bases.html" },
                { name: "Atomic Structure", url: "atomic-structure.html" }
            ]
        },
        "Class 9": {
            "Math": [
                { name: "Statistics", url: "statistics.html" },
                { name: "Probability", url: "probability.html" }
            ],
            "Physics": [
                { name: "Newton's Laws", url: "newtons-laws.html" },
                { name: "Kinetic Energy", url: "kinetic-energy.html" }
            ],
            "Biology": [
                { name: "Cell Structure", url: "cell-structure.html" },
                { name: "Human Anatomy", url: "human-anatomy.html" }
            ]
        },
        "Class 10": {
            "Trigonometry": [
                { name: "Trigonometric Functions", url: "trigonometric-functions.html" },
                { name: "Unit Circle", url: "unit-circle.html" }
            ],
            "Physics": [
                { name: "Work and Energy", url: "work-and-energy.html" },
                { name: "Thermal Expansion", url: "thermal-expansion.html" }
            ],
        },
        "Intermediate 1st Year": {
            "Physics": [
                { name: "Kinematics", url: "kinematics.html" },
                { name: "Circular Motion", url: "circular-motion.html" }
            ],
            "Chemistry": [
                { name: "Periodic Table", url: "periodic-table.html" },
                { name: "Chemical Reactions", url: "chemical-reactions.html" }
            ],
            "Biology": [
                { name: "Photosynthesis", url: "photosynthesis.html" },
                { name: "Cell Respiration", url: "cell-respiration.html" }
            ],
            "Math": [
                { name: "Calculus Basics", url: "calculus-basics.html" },
                { name: "Differential Equations", url: "differential-equations.html" }
            ]
        },
        "Intermediate 2nd Year": {
            "Physics": [
                { name: "Electromagnetism", url: "electromagnetism.html" },
                { name: "Optics", url: "optics.html" }
            ],
            "Chemistry": [
                { name: "Stoichiometry", url: "stoichiometry.html" },
                { name: "Thermodynamics", url: "thermodynamics.html" }
            ],
            "Biology": [
                { name: "Genetics", url: "genetics.html" },
                { name: "Evolution", url: "evolution.html" }
            ],
            "Math": [
                { name: "Statistics and Probability", url: "statistics-and-probability.html" },
                { name: "Sequences and Series", url: "sequences-and-series.html" }
            ]
        },
        "CSE": {
            "Data Structures": [
                { name: "Array Visualization", url: "array-visualization.html" },
                { name: "Tree Structures", url: "tree-structures.html" }
            ],
            "C": [
                { name: "C Programming Basics", url: "c-programming-basics.html" },
                { name: "C Compiling and Debugging", url: "c-compiling-and-debugging.html" }
            ]
            // Add other CSE subjects similarly...
        },
        "ECE": {
            "Digital Circuits": [
                { name: "Logic Gate Simulator", url: "logic-gate-simulator.html" },
                { name: "Karnaugh Map Minimization", url: "karnaugh-map-minimization.html" }
            ]
            // Add other ECE subjects similarly...
        },
        "EEE": {
            "Power Systems": [
                { name: "Power Flow Analysis", url: "power-flow-analysis.html" },
                { name: "Electrical Circuit Simulator", url: "electrical-circuit-simulator.html" }
            ]
            // Add other EEE subjects similarly...
        },
        "Mechanical": {
            "Thermodynamics": [
                { name: "Heat Transfer", url: "heat-transfer.html" },
                { name: "Thermal Systems", url: "thermal-systems.html" }
            ]
            // Add other Mechanical subjects similarly...
        },
        "Civil": {
            "Structural Analysis": [
                { name: "Beam Analysis", url: "beam-analysis.html" },
                { name: "Concrete Design", url: "concrete-design.html" }
            ]
            // Add other Civil subjects similarly...
        }
 };
        
function selectClass(className) {
    localStorage.setItem("selectedClass", className);
    speakText(`You selected ${className}`);
    setTimeout(() => window.location.href = "subjects.html", 1500);
}

function saveProfile() {
    let userName = document.getElementById("userName").value;
    if (userName.trim() === "") {
        alert("Please enter your name!");
        return;
    }
    localStorage.setItem("userName", userName);
    speakText(`Welcome, ${userName}`);
    setTimeout(() => window.location.href = "class-selection.html", 1500);
}

document.addEventListener("DOMContentLoaded", function () {
    let userName = localStorage.getItem("userName");
    if (userName && document.getElementById("welcomeMessage")) {
        document.getElementById("welcomeMessage").innerText = `Welcome, ${userName}! Select Your Class`;
    }

    let selectedClass = localStorage.getItem("selectedClass");
    if (selectedClass && document.getElementById("subjectHeader")) {
        document.getElementById("subjectHeader").innerText = `Subjects for ${selectedClass}`;
        speakText(`Here are the subjects for ${selectedClass}`);

        let subjectsList = document.getElementById("subjectsList");
        subjectsList.innerHTML = "";
        subjectsData[selectedClass].forEach(subject => {
            let btn = document.createElement("button");
            btn.className = "btn bg-blue-500 text-white px-6 py-3 rounded-md shadow-md hover:bg-blue-700 transition";
            btn.innerText = subject;
            btn.onclick = () => selectSubject(subject);
            subjectsList.appendChild(btn);
        });
    }

    let selectedSubject = localStorage.getItem("selectedSubject");
    if (selectedSubject && document.getElementById("experimentHeader")) {
        document.getElementById("experimentHeader").innerText = `Experiments for ${selectedSubject}`;
        speakText(`Here are the experiments for ${selectedSubject}`);

        let experimentsList = document.getElementById("experimentsList");
        experimentsList.innerHTML = "";

        let classExperiments = experimentsData[selectedClass]?.[selectedSubject] || [];
        classExperiments.forEach(experiment => {
            let listItem = document.createElement("div");
            listItem.className = "bg-gray-200 p-3 rounded-md shadow-md mb-2 hover:bg-gray-300 cursor-pointer transition";
            listItem.innerText = experiment.name;

            listItem.onclick = () => {
                localStorage.setItem("selectedExperiment", JSON.stringify(experiment));
                speakText(`Opening experiment: ${experiment.name}`);
                if (experiment.url) {
                    window.location.href = experiment.url;
                } else {
                    window.location.href = "experiment.html";
                }
            };

            experimentsList.appendChild(listItem);
        });
    }
});

function selectSubject(subject) {
    localStorage.setItem("selectedSubject", subject);
    speakText(`You selected ${subject}`);
    setTimeout(() => window.location.href = "experiments.html", 1500);
}

function speakText(text) {
    let speech = new SpeechSynthesisUtterance(text);
    speech.lang = "en-US";
    speech.rate = 1;
    speech.pitch = 1;
    window.speechSynthesis.speak(speech);
}
